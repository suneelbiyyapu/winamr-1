﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using winamr.Contracts.Services.General;
using winamr.Models;
using Xamarin.Forms;

namespace winamr.ViewModels
{
    public class DeviceListViewModel : BaseViewModel
    {


        #region Properties

        private ObservableCollection<DeviceGroupList> _deviceGroupsList;
        public ObservableCollection<DeviceGroupList> DeviceGroupsList
        {
            get => _deviceGroupsList;
            set
            {
                _deviceGroupsList = value;
                OnPropertyChanged(nameof(DeviceGroupsList));
            }
        }

        private ObservableCollection<DeviceGroup> _deviceGroups;
        public ObservableCollection<DeviceGroup> DeviceGroups
        {
            get => _deviceGroups;
            set
            {
                _deviceGroups = value;
                OnPropertyChanged(nameof(DeviceGroups));
            }
        }

        private bool isCreateDeviceGroupVisible;
        public bool IsCreateDeviceGroupVisible
        {
            get => isCreateDeviceGroupVisible;
            set
            {
                isCreateDeviceGroupVisible = value;
                OnPropertyChanged(nameof(IsCreateDeviceGroupVisible));
            }
        }

        private string deviceGroupName;
        public string DeviceGroupName
        {
            get => deviceGroupName;
            set
            {
                deviceGroupName = value;
                OnPropertyChanged(nameof(IsCreateDeviceGroupVisible));
            }
        }

        private bool tab1Visible;
        public bool Tab1Visible
        {
            get => tab1Visible;
            set
            {
                tab1Visible = value;
                OnPropertyChanged(nameof(Tab1Visible));
            }
        }

        private bool tab2Visible;
        public bool Tab2Visible
        {
            get => tab2Visible;
            set
            {
                tab2Visible = value;
                OnPropertyChanged(nameof(Tab2Visible));
            }
        }

        private bool tab3Visible;
        public bool Tab3Visible
        {
            get => tab3Visible;
            set
            {
                tab3Visible = value;
                OnPropertyChanged(nameof(Tab3Visible));
            }
        }

        #endregion

        #region Constructor

        public DeviceListViewModel(IConnectionService connectionService,
            INavigationService navigationService,
            IDialogService dialogService) : base(connectionService, navigationService, dialogService)
        {
            // handle this
            DeviceGroups = new ObservableCollection<DeviceGroup>();
            DeviceGroupsList = new ObservableCollection<DeviceGroupList>();
            LoadDeviceGroups();
            DisplayTabs("1");
            this.IsCreateDeviceGroupVisible = false;
        }

        #endregion

        #region Commands

        /*
        public ICommand PieTappedCommand => new Command<Pie>(OnPieTapped);
        public ICommand AddToCartCommand => new Command<Pie>(OnAddToCart);
        */
        public ICommand AddDeviceGroupCommand => new Command(OnAddDeviceGroupTapped);
        public ICommand SaveCommand => new Command(OnSaveDeviceGroupTapped);
        public ICommand CancelCommand => new Command(OnCancelDeviceGroupTapped);
        public ICommand RemoveCommand => new Command(OnRemoveDeviceGroupTapped);
        public ICommand DeviceGroupTappedCommand => new Command(OnDeviceGroupTapped);
        public ICommand ToggleIsDeviceGroupEnableCommand => new Command(OnToggleIsDeviceGroupEnable);
        public ICommand TabTappedCommand => new Command<object>((value) => OnTabTappedCommand(value));

        #endregion

        #region Virtual Method InitializeAsync

        public override Task InitializeAsync(object data)
        {
            // PiesOfTheWeek = (await _catalogDataService.GetPiesOfTheWeekAsync()).ToObservableCollection();
            return Task.FromResult(false);
        }

        #endregion

        #region Private Methods

        /*
        private void OnPieTapped(Pie selectedPie)
        {
            _navigationService.NavigateToAsync<PieDetailViewModel>(selectedPie);
        }

        private async void OnAddToCart(Pie selectedPie)
        {
            MessagingCenter.Send(this, MessagingConstants.AddPieToBasket, selectedPie);
            await _dialogService.ShowDialog("Pie added to your cart", "Success", "OK");
        }
        */
        private async void OnAddDeviceGroupTapped(object addDeviceGroupTappedEventArgs)
        {
            this.IsCreateDeviceGroupVisible = true;
        }
        private async void OnDeviceGroupTapped(object deviceGroupTappedEventArgs)
        {
            var selectedDeviceGroup = deviceGroupTappedEventArgs as DeviceGroup;
            await _navigationService.NavigateToAsync<DeviceViewModel>(selectedDeviceGroup);
        }

        private void OnToggleIsDeviceGroupEnable(object toggleDeviceGroupTappedEventArgs)
        {

        }

        private void OnSaveDeviceGroupTapped(object saveDeviceGroupTappedEventArgs)
        {
            ObservableCollection<Models.Device> lstDevice = new ObservableCollection<Models.Device>()
            {
                new Models.Device(){DeviceId=1, DeviceName="Device #1", DeviceType="Type1", IsDeviceEnable=true},
                new Models.Device(){DeviceId=2, DeviceName="Device #2", DeviceType="Type2", IsDeviceEnable=false},
                new Models.Device(){DeviceId=3, DeviceName="Device #3", DeviceType="Type3", IsDeviceEnable=true},
                new Models.Device(){DeviceId=4, DeviceName="Device #4", DeviceType="Type4", IsDeviceEnable=false},
                new Models.Device(){DeviceId=5, DeviceName="Device #5", DeviceType="Type5", IsDeviceEnable=true},
            };

            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = DeviceGroups.Count + 1,
                DeviceGroupName = DeviceGroupName,
                IsDeviceGroupEnable = true,
                Devices = lstDevice
            });

            this.IsCreateDeviceGroupVisible = false;
        }

        private void OnCancelDeviceGroupTapped(object cancelDeviceGroupTappedEventArgs)
        {
            this.IsCreateDeviceGroupVisible = false;
        }

        private void OnRemoveDeviceGroupTapped(object removeDeviceGroupTappedEventArgs)
        {
            DeviceGroups.Remove(removeDeviceGroupTappedEventArgs as DeviceGroup);
        }

        private void OnTabTappedCommand(object value)
        {
            DisplayTabs(value.ToString());
        }

        private void DisplayTabs(string value)
        {
            if (value == "1")
            {
                Tab1Visible = true;
                Tab2Visible = false;
                Tab3Visible = false;
            }
            else if (value == "2")
            {
                Tab1Visible = false;
                Tab2Visible = true;
                Tab3Visible = false;
            }
            else
            {
                Tab1Visible = false;
                Tab2Visible = false;
                Tab3Visible = true;
            }
        }

        private void LoadDeviceGroups()
        {
            // Devices list
            ObservableCollection<Models.Device> lstDevice = new ObservableCollection<Models.Device>()
            {
                new Models.Device(){DeviceId=1, ImageUrl = "fan.jpg", DeviceName="Fan", DeviceType="Type1", IsDeviceEnable=true},
                new Models.Device(){DeviceId=2, ImageUrl = "bulb.jpeg", DeviceName="Bulb", DeviceType="Type2", IsDeviceEnable=false},
                new Models.Device(){DeviceId=3, ImageUrl = "aircooler.png", DeviceName="Air Cooler", DeviceType="Type3", IsDeviceEnable=true},
                new Models.Device(){DeviceId=4, ImageUrl = "Television.png", DeviceName="Television", DeviceType="Type4", IsDeviceEnable=false},
                new Models.Device(){DeviceId=5, ImageUrl = "refrigerator.jpeg", DeviceName="Refrigerator", DeviceType="Type5", IsDeviceEnable=true},
                new Models.Device(){DeviceId=6, ImageUrl = "ovan.jpeg", DeviceName="Microwave oven", DeviceType="Type6", IsDeviceEnable=true},
            };
            
            // Device Groups List
            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = 1,
                DeviceGroupName = "Home",
                IsDeviceGroupEnable = true,
                Devices = lstDevice,
                ImageUrl= "home.jpg",
                ChildDeviceGroups = new ObservableCollection<DeviceGroup>()
                {
                    new DeviceGroup
                    {
                        DeviceGroupId = 1,
                        DeviceGroupName = "Hall",
                        IsDeviceGroupEnable = true,
                        Devices = lstDevice,
                        ImageUrl= "hall.jpeg",
                        ChildDeviceGroups = null
                    },
                    new DeviceGroup
                    {
                        DeviceGroupId = 2,
                        DeviceGroupName = "Bed Room",
                        IsDeviceGroupEnable = false,
                        Devices = lstDevice,
                        ImageUrl="bedroom.jpeg",
                        ChildDeviceGroups = null
                    },
                    new DeviceGroup
                    {
                        DeviceGroupId = 3,
                        DeviceGroupName = "Kitchen",
                        IsDeviceGroupEnable = true,
                        Devices = lstDevice,
                        ImageUrl="kitchen.jpeg",
                        ChildDeviceGroups = null
                    }
                }
            });

            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = 2,
                DeviceGroupName = "Office",
                IsDeviceGroupEnable = false,
                Devices = lstDevice,
                ImageUrl= "office.jpeg",
                ChildDeviceGroups = null
            });

            /*
            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = 3,
                DeviceGroupName = "Device Group #3",
                IsDeviceGroupEnable = true,
                Devices = lstDevice,
                ChildDeviceGroups = null
            });

            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = 4,
                DeviceGroupName = "Device Group #4",
                IsDeviceGroupEnable = false,
                Devices = lstDevice,
                ChildDeviceGroups = null
            });

            DeviceGroups.Add(new DeviceGroup
            {
                DeviceGroupId = 5,
                DeviceGroupName = "Device Group #5",
                IsDeviceGroupEnable = true,
                Devices = lstDevice,
                ChildDeviceGroups = null
            });
            */

            // List of Device Groups List
            // DeviceGroupsList.Add(new DeviceGroupList
            // {
            //     ListofDeviceGroups = DeviceGroups,
            //     Devices = lstDevice
            // });
        }

        #endregion
    }
}
