﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace winamr.Models
{
    public class DeviceGroupList
    {
        public int DeviceGroupListId { get; set; }
        public string DeviceGroupListName { get; set; }
        public bool IsDeviceGroupListEnable { get; set; }
        public ObservableCollection<Device> Devices { get; set; }
        public ObservableCollection<DeviceGroup> ListofDeviceGroups { get; set; }
    }
}
